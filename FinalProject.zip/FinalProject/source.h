#ifndef SOURCE_H
#define SOURCE_H
#include <iostream>
#include <vector>

using namespace std;


struct recurringData{
//year,team,league,salary
    int year;
    string team;
    string league;
    int salary;

};

struct player{

    string key;
    string playerID;
    string lastname;
    string firstname;
    int birthyear=0;
    string birthcountry;
    int weight=0;
    int height;
    string batright;
    string throwright;
    int yindex=0;
    recurringData stats;
    vector <recurringData> yearData;
};

struct node{
    player p;
    node *nextplayer;
    node(){}

    node(player x, node *y){
        p = x;
        nextplayer = y;
    }
};


class source{

public:
    source();
    void printPlayer(string, int, int);
    void addPlayer(player, int);
    int vectorsize;
    int chainCollisions =0;
    int chainSearches =0;
    int sumofString(string);
    vector <node*> league;

private:

};


class openAddress{

public:
    int openCollisions =0;
    int openSearches =0;
    void addPlayer(player, int);
    int sumofString(string);
    vector <player> league;
    int vectorsize;
    bool isfull = false;
    int index=0;
    void printPlayer(string, int);

};

#endif
