#include <iostream>
#include "source.h"
#include <fstream>
#include <cstdlib>
#include <vector>
#include <sstream>
#include <typeinfo>

using namespace std;

int main(int argc, char* argv[]){

    source s;
    openAddress o;
    //int size = atoi(argv[1]);
    s.vectorsize = 5148;
    o.vectorsize = 5148;

    s.league.resize(s.vectorsize);
    o.league.resize(o.vectorsize);

    //char* filename = argv[1];
    char* filename = "playerData";
    ifstream data (filename);
    string word;
    int index =0;
    while(getline(data, word, '\n')) {//parses by line
        index = 0;
        string first;
        stringstream fs;
        fs<<word;

        getline(fs,first,',');
        if(first == "yearID"){//skips the header line
            continue;
        }

        stringstream ss;
        ss<<word;
        player p;

        recurringData t;
        p.yearData.push_back(t);
        while(getline(ss, word, ',')) {//parses by word

            if(index == 0){
                int year = stoi(word);
                p.stats.year = year;
            }
            if(index == 1){
                p.stats.team = word;
            }
            if(index == 2){
                p.stats.league = word;
            }
            if(index == 3){
                p.playerID = word;
            }
            if(index == 4){
                int salary = stoi(word);
                p.stats.salary = salary;
            }
            if(index == 5){
                p.firstname = word;
            }
            if(index == 6){
                p.lastname = word;

            }
            if(index == 7){
                int byear = stoi(word);
                p.birthyear = byear;
            }
            if(index == 8){
                p.birthcountry = word;
            }
            if(index == 9){
                int weight = stoi(word);
                p.weight = weight;
            }
            if(index == 10){
                int height = stoi(word);
                p.height = height;
            }
            if(index == 11){
                p.batright = word;
            }
            if(index == 12){
                p.throwright = word;
            }

            index++;
        }

        string key = p.firstname + p.lastname;//key
        int sum = s.sumofString(key);//ACII sum of key
        p.key = key;//player key is now string key
        s.addPlayer(p, sum);
        if(o.isfull == false){
            o.addPlayer(p, sum);
        }
    }

    cout<<"Hash table size: "<<s.vectorsize<<endl;
    cout<<"Collisions using open addressing: "<<o.openCollisions<<endl;
    cout<<"Collisions using chaining: "<<s.chainCollisions<<endl;
    cout<<"Search operations using open addressing: "<<o.openSearches<<endl;
    cout<<"Search operations using chaining: "<<s.chainSearches<<endl;
    bool run=true;
    while(run){

        string command;
        cout << "======Main Menu======" << endl;
        cout << "1. Query hash table" << endl;
        cout << "2. Quit" << endl;

        getline(cin, command);
        if(command == "1"){
            string q;
            cout << "Enter a player key (ex. LenBarker):" << endl;
            getline(cin, q);
            string y;
            cout << "Enter their birth year (ex. 1955):" << endl;
            getline(cin, y);
            int yearBorn = stoi(y);
            int l = s.sumofString(q);
            s.printPlayer(q, l, yearBorn);
            o.printPlayer(q, l);
        }
        if(command == "2"){
            cout<<"Goodbye!"<<endl;
            run=false;
        }


    }
    return 0;
}
