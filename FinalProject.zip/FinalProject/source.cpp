#include "source.h"
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

source:: source(){
}

void source:: printPlayer(string name, int sum, int yearBorn){
    node* temp= league[sum];
    int searches=0;
    bool found=false;
    while(temp != NULL){
        if(name == temp->p.key && yearBorn ==temp->p.birthyear){
            found=true;
            cout<<"First name: "<<temp->p.firstname<<endl;
            cout<<"Last name: "<<temp->p.lastname<<endl;
            cout<<"Year born: "<<temp->p.birthyear<<endl;
            cout<<"Country born: "<<temp->p.birthcountry<<endl;
            cout<<"Weight: "<<temp->p.weight<<endl;
            cout<<"Height: "<<temp->p.height<<endl;
            cout<<"Bats: " <<temp->p.batright<<endl;
            cout<<"Throws: "<<temp->p.throwright<<endl;
            cout<<"Teams and Salary:"<<endl;
            for(int i=1;i<temp->p.yearData.size();i++){
                cout<<temp->p.yearData[i].year<<",";
                cout<<temp->p.yearData[i].team<<",";
                cout<<temp->p.yearData[i].league<<",";
                cout<<temp->p.yearData[i].salary<<endl;
            }
            break;
        }
        searches++;
        temp=temp->nextplayer;
    }
    if(found==false){
        cout<<"Player not found using chaining."<<endl;
    }
    cout<<"Search operations using chaining: "<<searches<<endl;
    return;
}

void openAddress:: printPlayer(string name, int sum){
    int searches=0;
    if(league[sum].key == name){
        cout<<"Search operations using open addressing: "<<searches<<endl;
        return;
    }

    for(int i=0; i< league.size();i++){
        searches++;
        if(league[i].key == name){
            cout<<"Search operations using open addressing: "<<searches<<endl;
            return;
        }
    }
    cout<<"Player not found using open addressing."<<endl;
    cout<<"Search operations using open addressing: "<<searches<<endl;

}

int source:: sumofString(string word){
    int sum=0;
    for(int i=0;i<word.size();i++){
        sum+=word[i];
    }
    sum = sum%vectorsize;
    return sum;
}

int openAddress:: sumofString(string word){
    int sum=0;
    for(int i=0;i<word.size();i++){
        sum+=word[i];
    }
    sum = sum%vectorsize;
    return sum;
}

void source:: addPlayer(player p, int sum){

    node *newplayer = new node(p,NULL);
    if(league[sum] == NULL){
        league[sum] = newplayer;
        league[sum]->p.yearData.push_back(p.stats);
        return;
    }
    else{
        if(league[sum]->p.height == p.height && league[sum]->p.weight == p.weight && league[sum]->p.birthyear == p.birthyear){
            league[sum]->p.yearData.push_back(p.stats);//if the first spot is the first player
            return;
        }

        chainCollisions++;
        //cout<<p.key<<endl;
        //cout<<chainCollisions<<endl;
        if(league[sum]->nextplayer == NULL){
            chainSearches++;
            league[sum]->nextplayer = new node(p,NULL);
            league[sum]->nextplayer->p.yearData.push_back(p.stats);
            return;
        }

        node *temp = league[sum]->nextplayer;

        while(temp->nextplayer != NULL){
            if(temp->p.height == p.height && temp->p.weight == p.weight && temp->p.birthyear == p.birthyear){
                temp->p.yearData.push_back(p.stats);
                return;
            }
            chainSearches++;
            temp=temp->nextplayer;
        }
        temp->nextplayer = newplayer;
        temp->p.yearData.push_back(newplayer->p.stats);

    }

}

void openAddress:: addPlayer(player newplayer, int sum){

    if(league[sum].weight == 0 && league[sum].birthyear == 0){
        league[sum]=newplayer;
        league[sum].yearData.push_back(newplayer.stats);
        index++;
        return;
    }

    if(league[sum].playerID == newplayer.playerID){
        league[sum].yearData.push_back(newplayer.stats);
        return;
    }
    openCollisions++;

    if(index >= vectorsize){
        cout<<vectorsize<<" was too small for open addressing."<<endl;
        isfull = true;
        return;
    }

    for(int i=0;i<vectorsize;i++){
        if(league[i].weight == 0){
            league[i] = newplayer;
            index++;
            return;
        }
        openSearches++;
        if(league[i].weight == newplayer.weight && league[i].height == newplayer.height && league[i].key == newplayer.key){
            league[i].yearData.push_back(newplayer.stats);
            return;
        }
    }
}
